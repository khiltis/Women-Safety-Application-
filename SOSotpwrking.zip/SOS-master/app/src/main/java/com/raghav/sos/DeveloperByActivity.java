package com.raghav.sos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DeveloperByActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer_by);
    }
}